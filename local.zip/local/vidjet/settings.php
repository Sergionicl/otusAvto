<?
define('C_REST_CLIENT_ID','local.6768382cbdcee6.15224724');//Application ID
define('C_REST_CLIENT_SECRET','dA8yRd5bKIsTrb8n52OiNJdmZtWXt3jNwJh6PesGhiatNwNZ1E');//Application key
// or
// define('C_REST_WEB_HOOK_URL','https://rest-course.bitrix24.ru/rest/1/j0nzq02mzvzmx9lx/');//url on creat Webhook

//define('C_REST_CURRENT_ENCODING','windows-1251');
//define('C_REST_IGNORE_SSL',true);//turn off validate ssl by curl
define('C_REST_LOG_TYPE_DUMP',true); //logs save var_export for viewing convenience
//define('C_REST_BLOCK_LOG',true);//turn off default logs
define('C_REST_LOGS_DIR', __DIR__ .'/logs/'); //directory path to save the log