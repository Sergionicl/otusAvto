<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
$arComponentParameters = array(
   // "PARAMETERS" => array(
   //       "PARENT" => "BASE",
   //       "NAME" => "Папка с шаблонами",
   //       "TYPE" => "STRING",
   //       "ADDITIONAL_VALUES" => "Y",
   //       "DEFAULT" => "1"
   //  ),  
);
?>