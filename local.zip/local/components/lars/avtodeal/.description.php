<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); 
$arComponentDescription = array(
	"NAME" =>  "avtodeal",
	"DESCRIPTION" => "avtodeal",
	"PATH"=>array(
		"ID"=>"avtodeal",
	)
);
?>