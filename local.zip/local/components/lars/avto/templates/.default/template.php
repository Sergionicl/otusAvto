<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();


//require_once("/home/bitrix/www/bitrix/modules/main/include/prolog_before.php");

\Bitrix\Main\UI\Extension::load("ui.vue3");
\Bitrix\Main\UI\Extension::load('ui.bootstrap4');
// $APPLICATION->SetAdditionalCss("/local/lar_doc_tepmlates/css/uikit.css");
// $APPLICATION->AddHeadScript("/local/lar_doc_tepmlates/js/uikit.js");
// $APPLICATION->AddHeadScript("/local/lar_doc_tepmlates/js/uikit-icons.js");
CJSCore::init("sidepanel");
$APPLICATION->ShowHead();


?>

<div id="application"></div>
<style>
    #avto-head {
        background: #91be04;
        color: white;
        font-weight: 800;
        padding-top: 8px;
        padding-bottom: 8px;
    / / border-right: 1 px solid white;
    }

    .row-avto {
        padding-top: 4px;
        padding-bottom: 4px;
    }

    .row-avto:nth-child(2n+1) {
        background: #80808036;
        opacity: 0.7;

    }

    .row-avto:nth-child(2n) {
        background: #8080800d;
        opacity: 0.7;

    }

    .row-avto:hover {
        opacity: 1;
        cursor: pointer;
    }

    .col-avto {
        border-right: 1px solid white;
    }

    #krest {
        font-size: 35;
        color: #2fc6f8;
        display: flex;
        justify-content: right;
        opacity: 0.6;
    }

    #krest:focus,
    #krest:hover {
        opacity: 1;
        cursor: pointer;
    }

</style>


<script type="text/javascript">


    BX.ready(function () {

        const AvtoFull = {
            template: `
                <div class="row row-avto" @click='clickAvto'>

                    <div class="col-3 col-avto" >
                       <span>{{avto.car_brand}}</span>
                    </div>
                    <div class="col-3 col-avto">
                         <span>{{avto.model}}</span>
                    </div>
                    <div class="col-2 col-avto" >
                         <span>{{avto.year}}</span>
                    </div>
                    <div class="col-2 col-avto" >
                         <span>{{avto.color}}</span>
                    </div>
                    <div class="col-2" >
                         <span>{{avto.mileage}}</span>
                    </div>
                </div>
                    `,
            props: ["avto"],
            data() {
                return {
                    option: '',
                    value: '',
                }
            },
            created() {
            },
            methods: {
                clickAvto() {
                    console.log(this.avto.id);
                    BX.SidePanel.Instance.open("/local/components/lars/avtodeal/init_comp.php?avto_id=" + this.avto.id,
                        {
                            cacheable: false,
                        }
                    )
                }
            }
        };

        const Avto = {
            template: `
                {{checkeId}}
                <div class="row row-avto" >
                    <div class="col-1 col-avto">
                       <input type="radio" name="avtoId" :value="avto.id" @click="checkAvto(avto.id)" :checked="checkedId==avto.id">
                    </div>
                    <div class="col-3 col-avto" >
                       <span>{{avto.car_brand}}</span>
                    </div>
                    <div class="col-3 col-avto">
                         <span>{{avto.model}}</span>
                    </div>
                    <div class="col-2 col-avto" >
                         <span>{{avto.year}}</span>
                    </div>

                </div>

                    `,
            props: ["avto", "index", "checkedId"],
            data() {
                return {}
            },
            created() {
            },
            methods: {
                checkAvto(id) {
                    console.log("Сработал");
                    console.log(id);
                    this.$emit("checkAvto", id);
                }
            }
        };

        const a = BX.Vue3.BitrixVue.createApp({
            data() {
                return {
                    avtos: <? echo $arResult['AVTOS']; ?>,
                    mode: '<? echo $arResult['MODE']; ?>',
                    contactId: '<? echo $arResult['CONTACT_ID']; ?>',
                    dealId: <? echo $arResult['DEAL_ID']; ?>,
                    checkedId: <? echo $arResult['CHECKED_ID']; ?>,
                    newAvto: {
                        "id_client": "<? echo $arResult['CONTACT_ID']; ?>",
                        "car_brand": "",
                        "model": "",
                        "year": new Date(),
                        "color": "",
                        "mileage": ""
                    },
                    avtoId: '',
                    errors: ''
                }
            },
            created() {
            }
            ,
            methods: {
                saveAvto() {
                    console.log(this.newAvto);
                    BX.showWait();
                    BX.ajax.runComponentAction('lars:avto', "saveAvto", {
                        mode: 'class',
                        data: {
                            formData: this.newAvto
                        }
                    }).then(response => {
                        //console.log(response);
                        BX.closeWait();
                        if (response.status == 'success') {
                            //Сообщения об ошибке
                            if (typeof response.data.errors !== 'undefined') {
                                this.errors = response.data.errors;
                                //this.viewAlertBlock = true;
                            } else {
                                this.mode = 'LIST';
                                let addavto = this.newAvto
                                addavto.id = response.data;
                                this.avtos.push(addavto);
                            }
                        }
                    });
                },
                checkAvto(id) {
                    BX.showWait();
                    BX.ajax.runComponentAction('lars:avto', "checkAvto", {
                        mode: 'class',
                        data: {
                            avtoId: id,
                            dealId: this.dealId
                        }
                    }).then(response => {
                        console.log(response);
                        BX.closeWait();
                        if (response.status == 'success') {
                            //Сообщения об ошибке
                            if (typeof response.data.errors !== 'undefined') {
                                this.errors = response.data.errors;
                                //this.viewAlertBlock = true;
                            } else {
                                this.mode = 'CHECK';
                            }
                        }
                    });
                },
                deleteDeal() {
                    BX.showWait();
                    BX.ajax.runComponentAction('lars:avto', "deleteDeal", {
                        mode: 'class',
                        data: {
                            dealId: this.dealId
                        }
                    }).then(response => {
                        console.log(response);
                        BX.closeWait();
                        if (response.status == 'success') {
                            //Сообщения об ошибке
                            if (typeof response.data.errors !== 'undefined') {
                                this.errors = response.data.errors;
                                //this.viewAlertBlock = true;
                            } else {
                                this.mode = 'CHECK';
                            }
                        }
                    });
                },
                changeDealStage() {
                    BX.showWait();
                    BX.ajax.runComponentAction('lars:avto', "changeDealStage", {
                        mode: 'class',
                        data: {
                            dealId: this.dealId
                        }
                    }).then(response => {
                        console.log(response);
                        BX.closeWait();
                        if (response.status == 'success') {
                            //Сообщения об ошибке
                            if (typeof response.data.errors !== 'undefined') {
                                this.errors = response.data.errors;
                                //this.viewAlertBlock = true;
                            } else {
                                BX.SidePanel.Instance.closeAll([immediately = false])
                            }
                        }
                    });
                },
                openEditor() {
                    BX.SidePanel.Instance.open("/local/components/lars/avto/init_comp.php?contact_id=" + this.contactId,
                        {
                            cacheable: false,
                        }
                    )
                },
                addAvto() {
                    this.mode = 'FORM';
                }
            },
            computed: {},
            components: {
                AvtoFull,
                Avto
            },
            mounted() {
            },
            // language=Vue
            template: `
              <div class="container">
                <div class="row">
                  <div class="col-12">
                    <ul>
                      <li
                          v-for="(error, key, index) in errors"
                      >
                        Заказ-наряд (сделка) для данного автомобиля уже существует в сделке № {{error.deal_id}}<br>
                        <b>Удалить данную сделку или перенести на стадию отложить?</b>
                        <div class="row">
                          <div class="col-3">
                            <button class="btn btn-danger btn-sm" @click="deleteDeal">Удалить</button>
                          </div>
                          <div class="col-3">
                            <button class="btn btn-success btn-sm" @click="changeDealStage">Отложить</button>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div v-if="mode === 'LIST'">
                <h1 class="text-center">Автомобили клиента</h1>
                <div class="container">
                  <!--{{avtos}}-->
                  <div class="row" id="avto-head">
                    <div class="col-3 col-avto">
                      <span>Марка</span>
                    </div>
                    <div class="col-3 col-avto">
                      <span>Модель</span>
                    </div>
                    <div class="col-2 col-avto">
                      <span>Год</span>
                    </div>
                    <div class="col-2 col-avto">
                      <span>Цвет</span>
                    </div>
                    <div class="col-2">
                      <span>Пробег</span>
                    </div>
                  </div>
                  <AvtoFull
                      v-bind:avto="avto"
                      v-for="(avto, key, index) in avtos"
                  >
                  </AvtoFull>
                  <div class="row">
                    <div class="col-12">
                      <br>
                      <button @click="addAvto" class="btn btn-primary">Добавить авто</button>
                    </div>
                  </div>

                </div>
              </div>
              <div v-if="mode === 'CHECK'">
                <div class="container">
                  <div class="row"><span @click="openEditor" id="krest"> &#10021;</span>
                    <!--{{avtos}}-->
                    <div class="row" id="avto-head">
                      <div class="col-1 col-avto">
                        <span>V</span>
                      </div>
                      <div class="col-3 col-avto">

                        <span>Марка</span>
                      </div>
                      <div class="col-3 col-avto">
                        <span>Модель</span>
                      </div>
                      <div class="col-2 col-avto">
                        <span>Год</span>
                      </div>

                    </div>
                    <Avto
                        @check-avto="checkAvto"
                        v-for="(avto, key, index) in avtos"
                        v-bind:avto="avto"
                        v-bind:index="index"
                        v-bind:checkedId="checkedId"
                    >
                    </Avto>
                  </div>
                </div>
              </div>
              <div v-if="mode === 'FORM'">
                <h1 class="text-center">Добавить автомобиль</h1>
                <div class="container">
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <label>Марка</label>
                        <input type="text" class="form-control" v-model="newAvto.car_brand">
                      </div>
                      <div class="form-group">
                        <label>Бренд</label>
                        <input type="text" class="form-control" v-model="newAvto.model">
                      </div>
                      <div class="form-group">
                        <label>Год</label>
                        <input type="date" class="form-control" v-model="newAvto.year">
                      </div>
                      <div class="form-group">
                        <label>Цвет</label>
                        <input type="text" class="form-control" v-model="newAvto.color">
                      </div>
                      <div class="form-group">
                        <label>Километраж</label>
                        <input type="number" class="form-control" v-model="newAvto.mileage">
                      </div>
                      <br>
                      <button @click="saveAvto" class="btn btn-primary">Добавить авто</button>
                    </div>
                  </div>
                </div>
              </div>
            `
        }).mount('#application');


    })


</script>