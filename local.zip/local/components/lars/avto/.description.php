<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); 
$arComponentDescription = array(
	"NAME" =>  "avto",
	"DESCRIPTION" => "avto",
	"PATH"=>array(
		"ID"=>"avto",
	)
);
?>