<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

$arComponentParameters = array(
    "GROUPS" => array(
        "LIST" => array(
            "NAME" => "Списки",
            "SORT" => "300",
        ),
    ),
    "PARAMETERS" => array(
        "LIST_SINGLE" => array(
            "PARENT" => "LIST",
            "NAME" => "Список",
            "TYPE" => "LIST",
            "VALUES" => array(
                "1" => "Список авто",
                "2" => "Поиск авто",
            ),
            "MULTIPLE" => "N",
        ),
    ),
);
?>